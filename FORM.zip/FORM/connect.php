<?php
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
if (!empty($firstname)){
if (!empty($lastname)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "hello";
// Create connection
$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO checkout (first_name, last_name)
values ('$firstname','$lastname')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "First Name should not be empty";
die();
}
}
else{
echo "Last Name should not be empty";
die();
}
?>